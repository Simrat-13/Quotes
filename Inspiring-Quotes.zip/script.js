const quotes = [
  "Believe you can and you're halfway there. -Theodore Roosevelt",
  "The only limit to our realization of tomorrow will be our doubts of today. -Franklin D. Roosevelt",
  "It does not matter how slowly you go as long as you do not stop. -Confucius",
  "Your time is limited, don't waste it living someone else's life. -Steve Jobs",
  "The only way to do great work is to love what you do. -Steve Jobs",
  "All our dreams can come true, if we have the courage to pursue them.— Walt Disney.",
  "The future belongs to those who believe in the beauty of their dreams. — Eleanor Roosevelt.",
  "Dreams come true. ...",
  "Dream as if you'll live forever. ...",
  "Some men see things as they are and say why."
];

const quoteDisplay = document.getElementById('quote');
const authorDisplay = document.getElementById('author');
const generateButton = document.getElementById('generate');
const quoteContainer = document.querySelector('.quote-container');

generateButton.addEventListener('click', () => {
  const randomIndex = Math.floor(Math.random() * quotes.length);
  const selectedQuote = quotes[randomIndex].split('-');
  const quote = selectedQuote[0].trim();
  const author = selectedQuote[1].trim();

  gsap.to(quoteContainer, { opacity: 0, duration: 0.5, onComplete: updateQuote });

  function updateQuote() {
    quoteDisplay.textContent = quote;
    authorDisplay.textContent = `- ${author}`;

    gsap.to(quoteContainer, { opacity: 1, duration: 0.5 });
  }
});